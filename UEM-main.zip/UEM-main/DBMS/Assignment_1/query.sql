/*
        SQL Query for Assignment 1 in DBMS Lab.
 */

-- 1. Add foreign key constraint from Pno on ‘Works_on’ table to Project table on delete cascade
alter table WORKS_ON
    add foreign key (PNO)
        references PROJECT on delete cascade;

-- 2. Add Foreign Key from Essn on ‘Dependent’ Table To ‘Employee’ Table On Delete Cascade
alter table DEPENDENT
    add foreign key (ESSN)
        references EMPLOYEE on delete cascade;

-- 3. Retrieve the SSN values and department name for all employees.
select E.SSN, D.DNAME
from EMPLOYEE E,
     DIVISION D
where E.DNO = D.DNUMBER;

-- 4. Retrieve the birth date and address of the employee whose name is 'John B. Smith'.
select BDATE, ADDRESS
from EMPLOYEE E
where E.FNAME like 'John'
  and E.MINIT = 'B'
  and E.LNAME = 'Smith';

-- 5. Delete the Super_ssn column from the Employee Table.
alter table EMPLOYEE
    drop column SUPER_SSN;

-- 6. Add Foreign key constraint (ON DELETE CASCADE) on MGRSSN of Department table to Employee Table.
alter table DIVISION
    add foreign key (MGR_SSN)
        references EMPLOYEE on delete cascade;

-- 7. Change the length of Address column of Employee Table to varchar(100).
alter table EMPLOYEE
    modify address varchar(100);

-- 8. Retrieve the name and address of all employees who work for the 'Research' department.
select FNAME || ' ' || LNAME as "Full Name", ADDRESS
from EMPLOYEE e,
     DIVISION d
where d.DNUMBER = e.DNO
  and d.DNAME = 'Research';

-- 9. For every project located in 'Stafford', list the project number,
-- the controlling department number, and the department manager's last name, address, and birth date.
select PNUMBER, DNUM, LNAME, ADDRESS, BDATE
from PROJECT P,
     EMPLOYEE E
where PLOCATION = 'Stafford'
  and DNUM = e.DNO;

-- 10. For each employee, retrieve the employee's name, and the name of his or her immediate supervisor.
select e.FNAME, e.LNAME
from EMPLOYEE E,
     EMPLOYEE E2
where e.SSN = e2.SUPER_SSN;

-- 11. Retrieve all the attribute values of EMPLOYEES who work in department 5.
select *
from EMPLOYEE E
where e.DNO = 5;

-- 12. Retrieve all the attributes of an employee and attributes of DEPARTMENT
-- he works in for every employee of ‘Research’ department.
select *
from EMPLOYEE E
where e.DNO in (
    select d.DNUMBER
    from DIVISION D
    where d.DNAME = 'Research'
);

-- 13. Make a list of all project numbers for projects that involve an employee whose
-- last name is 'Smith' as a worker or as a manager of the department that controls the project.
select wo.PNO
from WORKS_ON WO
where wo.ESSN in (
    select e.SSN
    from EMPLOYEE E
    where e.LNAME = 'Smith'
);

-- 14. Retrieve the name and address of all employees who work for the 'Research' department.
select e.FNAME, e.MINIT, e.LNAME
from EMPLOYEE E
where e.DNO in (
    select d.DNUMBER
    from DIVISION D
    where d.DNAME = 'Research'
);

-- 15. Retrieve the name of each employee who has a dependent with the same first name as the employee.
select *
from EMPLOYEE E, DEPENDENT D
where d.DEPENDENT_NAME = e.FNAME;

-- 16. Retrieve the names of employees who have no dependents.
select *
from EMPLOYEE E
where e.SSN not in (
    select d.ESSN
    from DEPENDENT D
    );

-- 17. Retrieve the social security numbers of all employees who work on project number 1, 2, or 3.
select wo.ESSN
from WORKS_ON WO
where wo.PNO in (1, 2, 3);

-- 18. Find the maximum salary among employees who work for the 'Research' department.
select max(e.SALARY) from EMPLOYEE E, DIVISION D
where e.DNO = d.DNUMBER and d.DNAME = 'Research';

-- 19. For each department, retrieve the department number,
-- the number of employees in the department, and their average salary.
select e.DNO, count(e.DNO) as number_of_employees, avg(e.SALARY) as average_salary
from EMPLOYEE E
group by e.DNO
order by e.DNO;

-- 20. For each project, retrieve the project number, project name,
-- and the number of employees who work on that project.
select WO.PNO, P.PNAME, count(WO.ESSN) as number_of_employees
from WORKS_ON WO, PROJECT P
where WO.PNO = p.PNUMBER
group by WO.PNO, p.PNAME
order by WO.PNO;

-- 21. For each project on which more than two employees work,
-- retrieve the project number, project name, and the number of employees who work on that project.
select WO.PNO, p.PNAME, count(WO.ESSN)
from WORKS_ON WO, PROJECT P
where wo.PNO = p.PNUMBER
group by WO.PNO, p.PNAME
having count(WO.ESSN) > 2
order by wo.PNO;

-- 22. Retrieve all employees whose address is in Houston, Texas. Here, the value of the ADDRESS attribute
-- must contain the substring 'Houston,TX‘ in it.
select e.FNAME, e.ADDRESS from EMPLOYEE E
where e.ADDRESS like '%Houston TX%';

-- 23. Retrieve a list of employees and the projects each works in, ordered by the employee's department,
-- and within each department ordered alphabetically by employee last name.
select e.FNAME, e.LNAME, p.PNAME, e.DNO
from EMPLOYEE E, WORKS_ON WO, PROJECT P
where e.SSN = WO.ESSN and WO.PNO = p.PNUMBER
group by e.DNO, p.PNAME, e.LNAME, e.FNAME
order by e.DNO, e.LNAME;

-- 24. Retrieve the names of all employees who have two or more dependents.
select e.FNAME, e.LNAME, count(e.SSN)
from EMPLOYEE E, DEPENDENT D
where e.SSN = d.ESSN
group by e.FNAME, e.LNAME
having count(d.ESSN) >= 2;

-- 25. List the names of managers who have at least one dependent.
select e.FNAME, e.LNAME, count(d.ESSN)
from EMPLOYEE E, DEPENDENT D
where d.ESSN in (
    select e.SSN
    from EMPLOYEE E2
    where e.SSN = E2.SUPER_SSN
    )
group by e.FNAME, e.LNAME
having count(d.ESSN) >= 1;

-- 26. Change the location and controlling department number of project number 10 to 'Bellaire' and 5, respectively.
update PROJECT
set PLOCATION = 'Bellaire', PNUMBER = 5
where PNUMBER = 10;

-- 27. Give all employees in the 'Research' department a 10% raise in salary.
update EMPLOYEE
set SALARY = salary + (SALARY * 0.1)
where DNO in (
    select d.DNUMBER
    from DIVISION D
    where d.DNAME = 'Research'
    );

-- 28. Delete the details of the employee whose last name is ‘Brown’.
delete
from EMPLOYEE E
where e.LNAME = '%Brown%';

-- 29. Delete all the employees from the ‘Research’ department.
delete
from EMPLOYEE E
where e.DNO in (
    select d.DNUMBER
    from DIVISION D
    where d.DNAME = 'Research'
    );

/********************** END of Queries **********************/

