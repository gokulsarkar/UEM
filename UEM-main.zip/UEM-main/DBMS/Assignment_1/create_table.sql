create table division(
    dname varchar(20) unique,
    dnumber int,
    mgr_ssn numeric(10, 0),
    mgr_start_date date,
    primary key (dnumber)
);


create table employee(
    fname varchar(15),
    minit char,
    lname varchar(15),
    ssn numeric(10, 0),
    bdate date,
    address varchar(50) default 'XYZ',
    sex char,
    salary numeric(8, 0) check (salary > 20000),
    super_ssn numeric(10, 0),
    dno int,
    primary key (ssn),
    foreign key (dno) references division on delete cascade
);


create table division_locations(
    dnumber int,
    dlocation varchar(20),
    primary key (dnumber, dlocation),
    foreign key (dnumber) references division
);


create table project(
    pname varchar(20),
    pnumber int,
    plocation varchar(20) default 'XYZ',
    dnum int,
    primary key (pnumber),
    foreign key (dnum) references division on delete cascade
);


create table works_on(
    essn numeric(10, 0),
    pno int,
    hours numeric(4, 1),
    primary key (essn, pno),
    foreign key (essn) references employee on delete cascade
);


create table dependent(
    essn numeric(10, 0),
    dependent_name varchar(10),
    sex char,
    bdate date,
    relationship varchar(20) not null,
    primary key (essn, dependent_name)
);

-- drop table division;
-- drop table employee;
-- commit
-- drop table division_locations;
-- drop table project;
-- drop table works_on;
-- drop table dependent;