public class Multiple3 {
    public static void main(String[] args) {
        System.out.println("Pratik Mukherjee, Roll No: 45");
        int start = Integer.parseInt(args[0]);
        int end = Integer.parseInt(args[1]);
        for (int i = start; i < end; i++) {
            if (i % 3 == 0)
                System.out.print(i + "\t");
        }
    }
}
