public class Leap {
    public static void main(String[] args) {
        System.out.println("Pratik Mukherjee, Roll No: 45");
        int year = Integer.parseInt(args[0]);

        if (year%4 == 0 || (year %100 == 0 && year%400 == 0))
            System.out.println(year + " is a Leap Year.");
        else
            System.out.println(year + " is Not a Leap Year.");
    }
}
