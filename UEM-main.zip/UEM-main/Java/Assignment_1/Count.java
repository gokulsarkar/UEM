public class Count {
    public static void main(String[] args) {
        System.out.println("Pratik Mukherjee, Roll No: 45");
        System.out.println("Number of arguments entered is:\t"+ args.length);
    }
}
