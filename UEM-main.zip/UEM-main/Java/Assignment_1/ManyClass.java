class Hello1 {
    public static void main(String[] args) {
        System.out.println("Hello1 Class");
    }
}

class Hello2 {
    public static void main(String[] args) {
        System.out.println("Hello2 Class");
    }
}

class Hello3{
    public static void main(String[] args) {
        System.out.println("Hello3 Class");
    }
}

class Hello4{
    public static void main(String[] args) {
        System.out.println("Hello4 Class");
    }
}