public class Rectangle {
    public static void main(String[] args) {
        System.out.println("Pratik Mukherjee, Roll No: 45");
        System.out.println(
                "Area of this Rectangle is:\t" +
                        (Float.parseFloat(args[0]) * Float.parseFloat(args[1]))
        );

        System.out.println(
                "Perimeter of this Rectangle is:\t" +
                        (2 * (Float.parseFloat(args[0]) + Float.parseFloat(args[1])))
        );
    }
}
