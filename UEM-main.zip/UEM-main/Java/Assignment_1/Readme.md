    <=== Questions ===>

1. Write a Java Program to print your Name entered through the command line as an argument.<br><b>--> Name.java</b>

2. Write a Java program to convert Temperature from Fahrenheit to Celsius and vice versa.<br><b>--> Temperature.java</b>

3. Write a Java program to add two numbers.<br><b>--> Add.java</b>

4. Write a java Program to find the area and Perimeter of a rectangle.<br><b>--> Rectangle.java</b>

5. Write a program in Java to find the maximum of three numbers.<br><b>--> Maximum.java</b>

6. Write a Java Program to check whether a given year is a leap year.<br><b>--> Leap.java</b>

7. Create four different classes with three of them containing the function main. Save the file with a different name than that of the class name and run each of the classes with the main function.<br><b>--> ManyClass.java</b>

8. Write a java program to reverse a number entered as a command line argument.<br><b>--> Reverse.java</b>

9. Write a java Program to count the number of digits entered through the command line argument.<br><b>--> Count.java</b>

10. Write a java program to find all the multiples of 3 within a given range where the starting and ending value are entered through command line argument.<br><b>-->Multiple3.java</b>


