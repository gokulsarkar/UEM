public class Reverse {
    public static void main(String[] args) {
        System.out.println("Pratik Mukherjee, Roll No: 45");
        int x = Integer.parseInt(args[0]);
        int k = 0;
        while (x != 0){
            k *= 10;
            k += x % 10;
            x /= 10;
        }
        System.out.println("The Reverse of Given Number is:\t" + k);
    }
}
