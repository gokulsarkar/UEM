public class Name {
    public static void main(String[] args) {
        System.out.println("Pratik Mukherjee, Roll No: 45");
        for (String arg : args)
            System.out.print(arg + " ");
    }
}

