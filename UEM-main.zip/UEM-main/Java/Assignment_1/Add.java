public class Add {
    public static void main(String[] args) {
        System.out.println("Pratik Mukherjee, Roll No: 45");
        System.out.println(
                "The Sum is:\t" +
                (Float.parseFloat(args[0]) + Float.parseFloat(args[1]))
        );
    }
}

