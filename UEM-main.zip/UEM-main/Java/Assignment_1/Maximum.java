public class Maximum {
    public static void main(String[] args) {
        System.out.println("Pratik Mukherjee, Roll No: 45");
        float a = Float.parseFloat(args[0]);
        float b = Float.parseFloat(args[1]);
        float c = Float.parseFloat(args[2]);

        if (a > b && a > c)
            System.out.println("Maximum is:\t" + a);
        else if (b > a && b > c)
            System.out.println("Maximum is:\t" + b);
        else
            System.out.println("Maximum is:\t" + c);
    }
}


