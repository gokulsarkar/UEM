public class Temperature {
    public static void main(String[] args) {
        float cel, fah;
        cel = Float.parseFloat(args[0]);
        fah = ((9 * cel)/5) + 32;
        System.out.println(cel + "Degree Celsius= " + fah + " Degree fahrenheit.");

        fah = Float.parseFloat(args[0]);
        cel = (5 * (fah - 32))/9;
        System.out.println(fah + "Degree Fahrenheit = " + cel + " Degree Celsius");
    }
}

