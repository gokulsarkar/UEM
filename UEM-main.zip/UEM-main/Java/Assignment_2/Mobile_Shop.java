import smart.Smartphone;


public class Mobile_Shop {
    public static void main(String[] args) {
        Smartphone sp = new Smartphone();
        sp.display();
        sp.purchase();
        sp.display();
    }
}
