    <=== Questions ===>
1.	Write a Python program to addition, subtraction, multiplication & transpose operations for matrix.<br><b>--> Matrix.py</b><br><br>
2.	Write a Python program to find the frequency of each element in the array.<br><b>--> Frequency.py</b><br><br>
3.	Write a Python program to print the duplicate elements of an array.<br><b>--> Duplicate.py</b><br><br>
4.	Write a Python program to sort the elements of an array in ascending & descending order.<br><b>--> Sort.py</b><br><br>


