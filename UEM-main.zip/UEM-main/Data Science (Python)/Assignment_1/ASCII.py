x = input("Enter The Character:\t")
print("ASCII value is:\t", ord(x))
