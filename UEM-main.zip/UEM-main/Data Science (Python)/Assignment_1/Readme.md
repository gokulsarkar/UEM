    <=== Questions ===>
1.	Write a program in Python to print the factorial of a number.<br><b>--> Factorial.py</b><br><br>
2.	Write a program in Python to check whether a number is Armstrong or not.<br><b>--> Armstrong.py</b><br><br>
3.	Write a program in Python to print ASCII value of a character.<br><b>--> ASCII.py</b><br><br>
4.	Write a program in Python to find area of a circle.<br><b>--> Circle.py</b><br><br>
5.	Write a program in Python to find simple interest.<br><b>--> Simple_Interest.py</b><br><br>
6.	Write a program in Python to find compound interest.<br><b>--> Compound_Interest.py</b><br><br>


