def compound(p, t, r):
    print("The Principal is:\t", p)
    print("The Time Period is:\t", t)
    print("The Rate of Interest:\t", r)

    ci = p * pow((r + (1/100)), t)
    print("The Compound Interest is:\t", ci)
    return ci


compound(30, 20, 10)

