def numberOfDigits(x: int):
    count = 0
    while x != 0:
        count += 1
        x //= 10
    return count


def isArmstrong(x: int):
    sum = 0
    n = numberOfDigits(x)
    while x != 0:
        sum += ((x % 10) ** n)
        x //= 10
    return sum


test = 1634
print(isArmstrong(test) == test)



