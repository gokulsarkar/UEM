def area(radius: int):
    import math
    return math.pi * radius * radius


radius = int(input("Enter The Radius:\t"))
print("The Area is:\t", area(radius))

