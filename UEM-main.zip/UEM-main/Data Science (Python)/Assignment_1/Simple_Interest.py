def simple(p, t, r):
    print("The Principle is:\t", p)
    print("The Time Period is:\t", t)
    print("The Rate of Interest is:\t", r)

    si = (p * t * r)/100
    print("The Simple Interest is:\t", si)
    return si


simple(30, 20, 10)

