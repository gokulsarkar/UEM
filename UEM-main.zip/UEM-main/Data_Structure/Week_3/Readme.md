# Questions

                   <==== Singly Linked List ====>
                
  1. Write a program to create a single linked list.
  2. Write a program to display a single linked list.
  3. Write a program to insert a node at the beginning of a single linked list.
  4. Write a program to insert a node at the end of a single linked list.
  5. Write a program to insert a node before a given node of a single linked list.
  6. Write a program to insert a node after a given node of a single linked list.
  7. Write a program to delete a node from the beginning of a single linked list.
  8. Write a program to delete a node from the end of a single linked list.
  9. Write a program to delete a node after a given node of a single linked list.
  10. Write a program to delete a node of a single linked list. 
  11. Write a program to delete the entire single linked list.

                  <==== Circular Linked List ====>
  1. Write a program to create a circular linked list.
  2. Write a program to display a circular linked list.
  3. Write a program to insert a node at the beginning of a circular linked list.
  4. Write a program to insert a node at the end of a circular linked list.
  5. Write a program to delete a node from the beginning of a circular linked list.
  6. Write a program to delete a node from the end of a circular linked list.
  7. Write a program to delete a node after a given node of a circular linked list. 
  8. Write a program to delete the entire circular linked list

