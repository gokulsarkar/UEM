# Questions

                    <==== Sorting Programs ====>

1. Write a program in C to sort an array using bubble sort algorithm.
2. Write a program in C to sort an array using insertion sort algorithm.
3. Write a program in C to sort an array using selection sort algorithm.
4. Write a program in C to sort an array using quick sort algorithm.
5. Write a program in C to sort an array using merge sort algorithm.

                    <==== Searching Programs ====>

6. Write a program to search an element in an array using linear search.
7. Write a program to search an element in an array using binary search.
8. Write a program to search an element in an array using interpolation search.

