# Questions

1. Write a program to insert an element in a BST.
2. Write a program to delete an element from a BST.
3. Write a program for Pre Order Traversal in a BST.
4. Write a program for In Order Traversal in a BST.
5. Write a program for Post Order Traversal in a BST.
6. Write a program to find the largest element in a BST.
7. Write a program to find the smallest element in a BST.
8. Write a program to count total number of nodes in a BST.
9. Write a program to determine the height of a BST.
10. Write a program to delete a BST.

