# Questions

1. Write a program to insert a number at a given location in an array.

2. Write a program to insert a number in a sorted array (ascending/descending).

3. Write a program to delete a number from a given location in an array.

4. Write a program to delete a number from a sorted array (ascending/descending).

5. Write a program to read an array of n numbers and then find the smallest number: Use the concept of passing an array to a function.

6. Write a program to interchange the largest and smallest number in an array: Use the concept of passing an array to a function.

7. Write a program to print elements of an m X n 2D array

8. Write a program to read a 2D array marks which stores marks of five students in three subjects and display the highest marks in each subject.

9. Write a program to transpose an m X n matrix.

10. Write a program to input two m X n matrices and then calculate the sum of their corresponding elements and store it in a third m X n matrix.

11. Write a program to read two matrices of dimension m X n and p X q respectively. Check the condition of matrix multiplicative and do the matrix multiplication to display the 3rd matrix.

12. Write a C program to find the largest number using Dynamic memory allocation.

13. Write a C program to show the implementation of malloc and free.
