# Questions

1. Write a C program to print array.
2. Write a C program to check whether a given string is a Palindrome or not.
3. Write a C program to convert temperature from degree Centigrade to Fahrenheit.
4. Write a C program to sorting an array.
5. Write a C program to print the largest and second largest element of the array.
6. Write a C program to display Fibonacci series.
7. Write a C program to print reverse array
8. Write a C program to check the sum of all elements of an array
9. Write a C program to check duplicate number in an array.

