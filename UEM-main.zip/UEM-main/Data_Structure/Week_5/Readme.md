# Questions

1. Write a program to insert an element into the queue using an array (Enqueue Operation).
2. Write a program to delete an element from the queue using an array (Dequeue Operation).
3. Write a program to return the value of the FRONT element of the queue(without deleting it from the queue) using an array (Peep operation).
4. Write a program to display the elements of a queue using an array.

