# Questions
1. Write a C program to find power of a number using for loop.
2. Write a program in C to count the digits of a given number using recursion.
3. Write a program in C to find the sum of all elements of the array. (Take input from User)
4. Write a program in C to convert any decimal number into its corresponding binary number. (Take input from User)
5. Write a program to multiply two matrices where the size & values are provided by the user.
