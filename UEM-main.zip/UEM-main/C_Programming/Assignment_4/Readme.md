# Questions 
              <==== Functions & Pointers ====>

1. Write a recursive function for finding the series of n:
            1^1 + 2^2 + 3^3 + 4^4 + ... + n^n
2. Write a C program to swap two values using pointers.
3. Write a program to calculate average of numbers between m and n using pointer.
4. Write a program in C to sort an array using Pointer.

