#include<stdio.h>


void main()
{
	char c;
	printf("Enter The Character:\t");
	scanf("%c", &c);
	printf("ASCII value of %c is %d", c, c);
}
