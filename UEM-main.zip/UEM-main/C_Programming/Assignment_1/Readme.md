# Questions
1. Write a C program to print “Hello World”.
2. Write a C program to perform the addition of two numbers without using + operator.
3. Write a C program to evaluate the arithmetic expression ((a + b / c * d - e) * (f - g)). Read the values a, b, c, d, e, f, g from the standard input device.
4. Write a C program to swap two numbers without a third variable.
5. Write a C program to calculate gross salary where the Basic, HRA percentage and DA percentage and fixed Medical allowance is provided by the user.
6. Write a C program to print the ASCII value of a character.
7. Write a C program to find the sum of individual digits of a 3 digit number.
8. Write a C program to convert Celsius to Fahrenheit and vice versa.
9. Write a C program to print hello world without semicolon.
10. Write a C program to check whether a number is even or odd using ternary operator
