#include<stdio.h>


void main()
{
	if (printf("Hello World")){}
}
